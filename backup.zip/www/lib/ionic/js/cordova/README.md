bower-cordova
=============

[cordova-js](https://github.com/apache/cordova-js) bower repository