<?php

$conn = mysqli_connect('localhost','root','','goal');

if (!$conn) {
	    die("connection failed:".mysqli_connect_error());
	    
	} 
		
	



?>